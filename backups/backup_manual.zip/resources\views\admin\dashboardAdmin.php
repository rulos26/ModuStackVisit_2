<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Administrativo</title>
</head>
<body>
    <h1>Bienvenido al Dashboard Administrativo</h1>
</body>
</html> 