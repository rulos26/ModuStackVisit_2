<?php

return [
    'app' => [
        'name' => 'Mi Aplicación',
        'env' => 'development',
        'debug' => true,
        'url' => 'http://localhost',
    ],
    'database' => [
        'host' => '127.0.0.1',
        'dbname' => 'u130454517_modulo_vista',
        'username' => 'u130454517_root',
        'password' => '0382646740Ju*',
        'charset' => 'utf8mb4'
    ]
]; 